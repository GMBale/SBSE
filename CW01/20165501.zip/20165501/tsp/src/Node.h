struct Node{
	int id;
	double x;
	double y;
};
